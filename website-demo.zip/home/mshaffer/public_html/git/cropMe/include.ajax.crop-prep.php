<?PHP

checkFolderRecursive($tmp);

// housecleaning ... remove all files when there are 25 in the folder ... 
	$files = scandir($tmp); unset($files[0]); unset($files[1]); sort($files);
	if(count($files) > 25)
		{
		foreach($files as $file) { @unlink($tmp.$file); }
		}

// variables defined as constants in include.functions.php
$local	= str_replace(BASE_URL,BASE_PATH,$data["image"]);
$stem	= $tmp. "I" . $now . "-" . $data["id"];  // we will determine extension within the function ... 


?>