<?PHP
$str = 'OTHER DEMOS:  [<a href="/">hello world</a>' . "] ";
	$template = ' [<a href="/demos/{demo}/">{demo}</a>]';
$demos = array("preview-popup", "required-attributes", "create-destroy", "show-hide", "replace-image", "resize-container", "ajax-crop", "ajax-crop-resize", "ajax-crop-rotate");
		foreach($demos as $demo)
			{
			$str .= str_replace("{demo}",$demo,$template);
			}
	$str .= " <BR /><BR /><BR /> ";
echo($str);
?>