<?PHP
require_once("/home/mshaffer/public_html/cropMe/include.functions.php");
	$ip = getClientIP();
	$finger = getFinger();
	
$optional_salt = "2b6e0b62fd145fc8a7abf47c0c603aed";
session_start();

if(!isset($_SESSION["date"])) 
	{
	$_SESSION["date"] = date("YmdG");
	}
if(!isset($_SESSION["hash"])) 
	{
		
	
	$hash = hash_hmac('sha256', session_id() . $optional_salt, $_SESSION["date"].'someSalt' . $ip . $finger);
	
	$_SESSION["hash"] = $hash;	
	
	
	}
	
$prefix = "cropMe-";
$more = true;	
	$page = $_SERVER["REQUEST_URI"];
	$nonce = uniqid($prefix,$more);
	$_nonce = md5( hash_hmac('sha256', $_SESSION["hash"], $page . $nonce) );
	
	//echo($_nonce);
// one browser, one session ... 
	$_SESSION["page"] = $page;
	$_SESSION["nonce"] = $nonce;
	$_SESSION["_nonce"] = $_nonce;
	
$str = '<SCRIPT>'
		. "\r\n"
		. 'var page = "'.$page.'";'
		. "\r\n"
		. 'var nonce = "'.$nonce.'";'
		. "\r\n"
		. '</SCRIPT>'
		. '';

echo($str);
?>