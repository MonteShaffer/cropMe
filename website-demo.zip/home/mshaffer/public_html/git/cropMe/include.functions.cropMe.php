<?PHP

function getExtension($str)
	{
	$tA = explode(".",trim($str)); $len = sizeof($tA);
		$ext = strtolower($tA[$len-1]);
		if($ext == "jpeg") { $ext = "jpg"; }
	return $ext;
	}
function cropMe($data,$local,$stem,$scale,$rotate)
	{
	$ext = getExtension($local);  // jpg, gif, png
		switch($ext)
			{
			case "jpg":
				 $im = imagecreatefromjpeg($local);
			break;
			case "png":
				$im = imagecreatefrompng($local);
			break;
			case "gif":
				$im = imagecreatefromgif($local);
			break;
			}


		$coords = array(
						"x"			=> round($data["x1"]), 
						"y"			=> round($data["y1"]), 
						"width"		=> round($data["w"]), 
						"height"	=> round($data["h"]),
							"iw"	=> round($data["iw"]), // extra for manual
							"ih"	=> round($data["ih"])
						);	
	if (function_exists('imagecrop')) 
			{
			$im = imagecrop($im, $coords);
			} 
			else 
				{
				$new = imagecreatetruecolor($coords["width"],$coords["height"]);
						imagecopy($new, $im, 0, 0, $coords["x"], $coords["y"], $coords["iw"], $coords["ih"]);
						imagedestroy($im);
				$im = $new;
				}

		if($scale)
			{
			$coords["newWidth"] = round($coords["width"] * $scale);
			$coords["newHeight"] = round($coords["height"] * $scale);

			$new = imagecreatetruecolor($coords["newWidth"],$coords["newHeight"]);
						imagecopyresampled($new, $im, 0, 0, 0, 0, $coords["newWidth"], $coords["newHeight"], $coords["width"], $coords["height"]);
						imagedestroy($im);
				$im = $new; 
			}

		if($rotate)
			{
			$background = imagecolorallocate($im, 0, 0, 0); // black
			$new = imagerotate ($im,$rotate,$background);
					imagedestroy($im);
				$im = $new; 
			}


		if($scale) { $stem .= "-scale_".$scale."_"; }
		if($rotate) { $stem .= "-rotate_".$rotate."_"; }
		$out = $stem . "." . $ext;
		switch($ext)
			{
			case "jpg":
				imagejpeg($im,$out,100);
			break;
			case "png":
				imagepng($im,$out);
			break;
			case "gif":
				imagegif($im,$out);
			break;
			}
		imagedestroy($im);

		chmod($out, _CHMOD_);
	return $out;
	}

// imagecopy($crop, $image, 0, 0, $x, $y, $w, $h);

?>
