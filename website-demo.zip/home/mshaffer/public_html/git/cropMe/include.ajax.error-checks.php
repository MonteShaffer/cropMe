<?PHP
require_once("/home/mshaffer/public_html/cropMe/include.functions.php");
	$ip = getClientIP();
	$finger = getFinger();
	
$optional_salt = "2b6e0b62fd145fc8a7abf47c0c603aed";
session_start();

// security checks
if(empty($_GET["a"]))						{ echo "ERROR #1: exiting"; exit; }
if($_GET["a"] != "crop-image")				{ echo "ERROR #2: exiting"; exit; }

if(empty($_GET["nonce"]))					{ echo "ERROR #3: exiting"; exit; }
if($_GET["nonce"] != $_SESSION["nonce"])	{ echo "ERROR #4: exiting"; exit; }

if(empty($_SESSION["hash"]))				{ echo "ERROR #5: exiting"; exit; }
if(empty($_SESSION["date"]))				{ echo "ERROR #6: exiting"; exit; }

$page = $_SESSION["page"];
if(empty($_POST["page"]))					{ echo "ERROR #7: exiting"; exit; }
if($_POST["page"] != $page)					{ echo "ERROR #8: exiting"; exit; }

if(empty($_POST["url"]))					{ echo "ERROR #9: exiting"; exit; }
if(strpos($_POST["url"],$page) === false)	{ echo "ERROR #10: exiting"; exit; }

$nonce = $_GET["nonce"];
$_nonce = md5( hash_hmac('sha256', $_SESSION["hash"], $page . $nonce) );

//echo($_nonce); 

if(empty($_SESSION["_nonce"]))				{ echo "ERROR #8: exiting"; exit; }
if($_SESSION["_nonce"] != $_nonce)			{ echo "ERROR #9: exiting"; exit; }


?>