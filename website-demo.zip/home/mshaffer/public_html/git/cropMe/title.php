<?PHP

$text = '<h1>cropMe  (jquery 2) plugin'
		. "\r\n"
		. '[<a href="https://github.com/MonteShaffer/cropMe/" target="_blank">github</a>]'
		. "\r\n"
		. '[<a href="/demos/preview-popup/">other demos</a>]'
		. "\r\n"
		. '</h1>'
		. '';

echo ($text);

?>