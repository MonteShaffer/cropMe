<?PHP
require_once("/home/mshaffer/public_html/cropMe/include.ajax.error-checks.php");  // will exit on error, first word is ERROR

$data = $_POST["myData"];
$now = microtime(true);
$tmp = realpath(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "tmp" . DIRECTORY_SEPARATOR;

require_once("/home/mshaffer/public_html/cropMe/include.ajax.crop-prep.php");

$scale		= false;
$rotate		= false;

require_once("/home/mshaffer/public_html/cropMe/include.functions.cropMe.php");
$out = cropMe($data,$local,$stem,$scale,$rotate);
	$web = str_replace(BASE_PATH,BASE_URL,$out);
	echo($web);exit;

?>