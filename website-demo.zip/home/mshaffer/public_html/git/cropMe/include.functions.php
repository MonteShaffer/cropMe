<?PHP

define("BASE_PATH", "/home/mshaffer/public_html/cropMe/");
define("BASE_URL", "http://cropMe.mshaffer.com/");
define("_CHMOD_", 0777);

function getClientIP() 
	{
	$array = array('REMOTE_ADDR', 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED');
	foreach ($array as $key) 
		{
		if (array_key_exists($key, $_SERVER) === true) 
			{
			foreach (explode(',', $_SERVER[$key]) as $ip) 
				{
				if (filter_var($ip, FILTER_VALIDATE_IP) !== false) 
					{
					return $ip;
					}
				}
			}
		}
	return "";
	}

function getFinger()
		{
		$user_agent = (!isset($_SERVER["HTTP_USER_AGENT"])) ? "-UNKNOWN-" : $_SERVER["HTTP_USER_AGENT"];		
		$extra = "thei;dijlkDj ljiowUPedkfjlksj";
		return md5( base64_encode( getBrowserFingerprint() . " | ". $user_agent." | " . $extra . " | " ) );
		}

function getBrowserFingerprint() 
	{
	$client_ip = getClientIP();
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$accept   = (!isset($_SERVER['HTTP_ACCEPT'])) ? "text/html" : $_SERVER['HTTP_ACCEPT'];
		$encoding = (!isset($_SERVER['HTTP_ACCEPT_ENCODING'])) ? "gzip" : $_SERVER['HTTP_ACCEPT_ENCODING'];
		$language = (!isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) ? "en-US" : $_SERVER['HTTP_ACCEPT_LANGUAGE'];
	$data = '';
	$data .= $client_ip;  # this may be a bad choice, not really if also tied to a user_id ??? ??? ... we already have a session, so it should be fine
	$data .= $useragent;
	$data .= $accept;
	$data .= $encoding;
	$data .= $language;
	/* Apply SHA256 hash to the browser fingerprint */
		$hash = hash('sha256', $data);
	return $hash;
	}


function checkFolderRecursive($dir,$skip=1,$perm=_CHMOD_)
		{			
		$tA = explode(DIRECTORY_SEPARATOR, $dir);
		
			$currentPath = "";
		for($j=0;$j<$skip;$j++)
			{
			$currentPath .= $tA[$j] . DIRECTORY_SEPARATOR;
			}
		
		for($i = 1;$i<=count($tA);$i++)
			{
				if(isset($tA[$i]))
				{
				if(trim($tA[$i])!="")
					{
					$currentPath .= $tA[$i] . DIRECTORY_SEPARATOR;
						checkFolder($currentPath);
					}
				}	
			}
		}

function checkFolder($dir,$perm=_CHMOD_)
		{			
		if(is_dir($dir)===false)
			{
			mkdir($dir) or die("failed making directory ". $dir);
			chmod($dir, $perm);
			}			
		}


?>